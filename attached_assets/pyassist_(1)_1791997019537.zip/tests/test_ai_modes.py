"""Automated integration tests for Gemini-powered Python Coding & Debugging Assistant modes.
Tests:
- Ask Python mode
- Generate Code mode
- Debug Code mode
- Explain Code mode
- Code Review mode
- Mode validation & input constraints
- Graceful error handling & fallback
"""
import pytest
from fastapi.testclient import TestClient

def test_invalid_mode_validation(client: TestClient, registered_user):
    cookies = registered_user["cookies"]
    csrf_token = cookies.get("pyassist_csrf", "")

    res = client.post(
        "/api/chat/ask",
        cookies=cookies,
        headers={"X-CSRF-Token": csrf_token},
        json={
            "question": "What is Python?",
            "mode": "unsupported_hack_mode"
        }
    )
    assert res.status_code == 422
    assert "Invalid mode" in str(res.json())

def test_oversized_code_input_limit(client: TestClient, registered_user):
    cookies = registered_user["cookies"]
    csrf_token = cookies.get("pyassist_csrf", "")

    oversized = "x = 1\n" * 900  # > 4000 chars
    res = client.post(
        "/api/chat/ask",
        cookies=cookies,
        headers={"X-CSRF-Token": csrf_token},
        json={
            "question": oversized,
            "mode": "review"
        }
    )
    assert res.status_code == 422

@pytest.mark.parametrize("mode,question", [
    ("ask", "What is the difference between is and == in Python?"),
    ("generate", "Write a Python function to compute the Fibonacci sequence using memoization."),
    ("debug", "Why does this give IndexError: nums = [1, 2]; print(nums[5])"),
    ("explain", "def quicksort(arr): return arr if len(arr) <= 1 else quicksort([x for x in arr[1:] if x < arr[0]]) + [arr[0]] + quicksort([x for x in arr[1:] if x >= arr[0]])"),
    ("review", "def calculate_sum(a, b):\n    total = a + b\n    return total")
])
def test_functional_ai_modes(client: TestClient, registered_user, mode, question):
    cookies = registered_user["cookies"]
    csrf_token = cookies.get("pyassist_csrf", "")

    res = client.post(
        "/api/chat/ask",
        cookies=cookies,
        headers={"X-CSRF-Token": csrf_token},
        json={
            "question": question,
            "mode": mode
        }
    )
    assert res.status_code == 200
    data = res.json()
    assert "conversation_id" in data
    assert "bot_message" in data
    assert len(data["bot_message"]["content"]) > 10
    assert data["mode"] == mode

def test_offline_fallback_simulation(client: TestClient, registered_user, monkeypatch):
    from pyassist.app.config import settings
    # Simulate missing API key
    monkeypatch.setattr(settings, "GEMINI_API_KEY", None)

    cookies = registered_user["cookies"]
    csrf_token = cookies.get("pyassist_csrf", "")

    # In ask mode, falls back to deterministic knowledge base
    res = client.post(
        "/api/chat/ask",
        cookies=cookies,
        headers={"X-CSRF-Token": csrf_token},
        json={
            "question": "What is Python?",
            "mode": "ask"
        }
    )
    assert res.status_code == 200
    data = res.json()
    assert data["bot_message"]["is_supported"] is True
    assert "Python" in data["bot_message"]["content"]
